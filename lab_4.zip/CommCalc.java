import java.util.Scanner;

public class CommCalc {
    private Auto autoPolicy;
    private Home homePolicy;
    private Life lifePolicy;
    private Scanner scanner;

    private boolean autoInfoEntered = false;
    private boolean homeInfoEntered = false;
    private boolean lifeInfoEntered = false;

    public CommCalc() {
        scanner = new Scanner(System.in);
        autoPolicy = null;
        homePolicy = null;
        lifePolicy = null;
    }

    public void Run() {
        int choice = 0;
        while (choice != 7) {
            printMenu();
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    autoInfo();
                    System.out.println("\nYour info has been saved.\n");
                    break;
                case 2:
                    homeInfo();
                    System.out.println("\nYour info has been saved.\n");
                    break;
                case 3:
                    lifeInfo();
                    System.out.println("\nYour info has been saved.\n");
                    break;
                case 4:
                    if (autoInfoEntered) {
                        System.out.println(autoPolicy);
                    } else {
                        System.out.println("Please enter auto policy information first (option 1).");
                    }
                    pause();
                    break;
                case 5:
                    if (homeInfoEntered) {
                        System.out.println(homePolicy);
                    } else {
                        System.out.println("Please enter home policy information first (option 2).");
                    }
                    pause();
                    break;
                case 6:
                    if (lifeInfoEntered) {
                        System.out.println(lifePolicy);
                    } else {
                        System.out.println("Please enter life policy information first (option 3).");
                    }
                    pause();
                    break;
                case 7:
                    System.out.println("Thank you for using Parkland Insurance. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
                    pause();
            }
        }
    }

    private void printMenu() {
        System.out.println("-----------------------------\n" +
                "Welcome to Parkland Insurance\n" +
                "-----------------------------\n" +
                "Enter any of the following:\n" +
                "1) Enter auto insurance policy information\n" +
                "2) Enter home insurance policy information\n" +
                "3) Enter life insurance policy information\n" +
                "4) Print auto policy\n" +
                "5) Print home policy\n" +
                "6) Print life policy\n" +
                "7) Quit\n");
    }

    private void pause() {
        System.out.println("Press Enter to return to the menu...");
        scanner.nextLine();
    }

    private void autoInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter make of vehicle: ");
        String make = scanner.nextLine();
        System.out.print("Enter model of vehicle: ");
        String model = scanner.nextLine();
        System.out.print("Enter amount of liability: ");
        double liability = scanner.nextDouble();
        System.out.print("Enter amount of collision: ");
        double collision = scanner.nextDouble();
        autoPolicy = new Auto(firstName, lastName, make, model, liability, collision);
        autoInfoEntered = true;
    }

    private void homeInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter house square footage: ");
        int footage = scanner.nextInt();
        System.out.print("Enter amount of dwelling: ");
        double dwelling = scanner.nextDouble();
        System.out.print("Enter amount of contents: ");
        double contents = scanner.nextDouble();
        System.out.print("Enter amount of liability: ");
        double liability = scanner.nextDouble();
        homePolicy = new Home(firstName, lastName, footage, dwelling, contents, liability);
        homeInfoEntered = true;
    }

    private void lifeInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter age of insured: ");
        int age = scanner.nextInt();
        System.out.print("Enter amount of term: ");
        double term = scanner.nextDouble();
        lifePolicy = new Life(firstName, lastName, age, term);
        lifeInfoEntered = true;
    }
}
